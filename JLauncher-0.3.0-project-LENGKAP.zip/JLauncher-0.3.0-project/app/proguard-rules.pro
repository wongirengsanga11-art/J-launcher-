# J Launcher release rules.
