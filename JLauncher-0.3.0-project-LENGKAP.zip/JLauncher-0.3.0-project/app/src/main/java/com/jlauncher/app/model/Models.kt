package com.jlauncher.app.model

data class MinecraftVersion(
    val id: String,
    val type: String,
    val releaseDate: String,
    val installed: Boolean = false
)

enum class LoaderType { VANILLA, FABRIC, FORGE, NEOFORGE, OPTIFINE }

data class ModItem(
    val name: String,
    val version: String,
    val loader: LoaderType,
    val installed: Boolean = false
)

data class ResourcePack(
    val name: String,
    val version: String,
    val enabled: Boolean = false
)

data class ShaderPack(
    val name: String,
    val version: String,
    val enabled: Boolean = false
)

enum class AccountType { MICROSOFT, ELY_BY, OFFLINE }

data class LauncherAccount(
    val name: String,
    val type: AccountType
)
