package com.jlauncher.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import com.jlauncher.app.ui.JLauncherApp
import com.jlauncher.app.ui.theme.JLauncherTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JLauncherTheme {
                Surface(modifier = androidx.compose.ui.Modifier.fillMaxSize()) {
                    JLauncherApp()
                }
            }
        }
    }
}
