package com.jlauncher.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFF66FFAA),
    onPrimary = Color(0xFF00150A),
    secondary = Color(0xFF8AD7FF),
    background = Color(0xFF07090E),
    surface = Color(0xFF11151F),
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun JLauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
