package com.jlauncher.app.data

import com.jlauncher.app.model.*

class JLauncherRepository {
    fun featuredVersions(): List<MinecraftVersion> = listOf(
        MinecraftVersion("1.21.8", "release", "2025-07-17"),
        MinecraftVersion("1.21.5", "release", "2025-03-25"),
        MinecraftVersion("1.20.4", "release", "2023-12-07"),
        MinecraftVersion("1.16.5", "release", "2021-01-15")
    )

    fun loaders(): List<LoaderType> = LoaderType.entries

    fun sampleMods(): List<ModItem> = listOf(
        ModItem("Sodium", "compatible", LoaderType.FABRIC),
        ModItem("JEI", "compatible", LoaderType.FORGE),
        ModItem("NeoForge Example", "compatible", LoaderType.NEOFORGE)
    )

    fun sampleResourcePacks(): List<ResourcePack> = listOf(
        ResourcePack("J Launcher Default", "1.21.x", true),
        ResourcePack("Clean UI", "1.20.x", false)
    )

    fun sampleShaders(): List<ShaderPack> = listOf(
        ShaderPack("J Neon Shader", "preview", false),
        ShaderPack("Vanilla Plus", "preview", false)
    )
}
