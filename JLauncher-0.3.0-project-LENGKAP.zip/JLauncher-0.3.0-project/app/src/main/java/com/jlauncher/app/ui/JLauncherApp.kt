package com.jlauncher.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.jlauncher.app.data.JLauncherRepository
import com.jlauncher.app.model.LoaderType

private val Neon = Color(0xFF66FFAA)
private val Panel = Color(0xFF11151F)
private val Bg = Color(0xFF07090E)

private data class NavItem(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun JLauncherApp() {
    val nav = rememberNavController()
    val items = listOf(
        NavItem("home", "Beranda", Icons.Default.Home),
        NavItem("versions", "Versi", Icons.Default.Extension),
        NavItem("mods", "Mod", Icons.Default.Build),
        NavItem("packs", "Pack", Icons.Default.Image),
        NavItem("shaders", "Shader", Icons.Default.LightMode),
        NavItem("makers", "Maker", Icons.Default.Create),
        NavItem("settings", "Pengaturan", Icons.Default.Settings)
    )

    Scaffold(
        containerColor = Bg,
        topBar = { TopAppBar(
            title = { Text("J LAUNCHER", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Bg,
                titleContentColor = Color.White
            )
        ) },
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                items.take(5).forEach { item ->
                    val selected = currentRoute(nav) == item.route
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            nav.navigate(item.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icon, null) },
                        label = { Text(item.title) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Neon,
                            selectedTextColor = Neon,
                            indicatorColor = Color(0xFF1A2A23)
                        )
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") { HomeScreen(nav) }
            composable("versions") { VersionsScreen() }
            composable("mods") { ModsScreen() }
            composable("packs") { PacksScreen() }
            composable("shaders") { ShadersScreen() }
            composable("makers") { MakersScreen() }
            composable("settings") { SettingsScreen() }
        }
    }
}

@Composable
private fun currentRoute(nav: androidx.navigation.NavHostController): String? =
    nav.currentBackStackEntryAsState().value?.destination?.route

@Composable
private fun HomeScreen(nav: androidx.navigation.NavHostController) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(20.dp)) {
                    Text("J Launcher", style = MaterialTheme.typography.headlineMedium, color = Neon, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Minecraft Java Launcher untuk Android", color = Color.White)
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { },
                        colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Color.Black),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("PLAY", fontWeight = FontWeight.Bold) }
                }
            }
        }
        item { SectionTitle("Game Bar") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FeatureCard("Versi", "Pilih Minecraft", Modifier.weight(1f)) { nav.navigate("versions") }
                FeatureCard("Mod", "Fabric / Forge", Modifier.weight(1f)) { nav.navigate("mods") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FeatureCard("Shader", "Kelola shader", Modifier.weight(1f)) { nav.navigate("shaders") }
                FeatureCard("Maker", "Buat konten", Modifier.weight(1f)) { nav.navigate("makers") }
            }
        }
        item { SectionTitle("Akun") }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Belum ada akun", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Microsoft • Ely.by • Offline/Local", color = Color.Gray)
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { }) { Text("Kelola akun") }
                }
            }
        }
    }
}

@Composable
private fun VersionsScreen() {
    val repo = remember { JLauncherRepository() }
    ContentList(
        title = "Versi Minecraft",
        subtitle = "Pilih dan siapkan versi Minecraft Java."
    ) {
        items(repo.featuredVersions()) { version ->
            ListCard("${version.id}  •  ${version.type}", "Belum terpasang") {
                Button(onClick = { }) { Text("INSTALL") }
            }
        }
    }
}

@Composable
private fun ModsScreen() {
    val repo = remember { JLauncherRepository() }
    ContentList("Mod & Modpack", "Dukungan loader disiapkan untuk Fabric, Forge, NeoForge, dan OptiFine.") {
        items(repo.sampleMods()) { mod ->
            ListCard(mod.name, "Loader: ${mod.loader}") { OutlinedButton(onClick = { }) { Text("KELOLA") } }
        }
    }
}

@Composable
private fun PacksScreen() {
    val repo = remember { JLauncherRepository() }
    ContentList("Resource Pack", "Pasang dan aktifkan resource pack.") {
        items(repo.sampleResourcePacks()) { pack ->
            ListCard(pack.name, pack.version) { Switch(checked = pack.enabled, onCheckedChange = { }) }
        }
    }
}

@Composable
private fun ShadersScreen() {
    val repo = remember { JLauncherRepository() }
    ContentList("Shader", "Kelola shader dan siapkan Shader Maker.") {
        items(repo.sampleShaders()) { shader ->
            ListCard(shader.name, shader.version) { Switch(checked = shader.enabled, onCheckedChange = { }) }
        }
    }
}

@Composable
private fun MakersScreen() {
    ContentList("Creative Makers", "Alat pembuatan konten J Launcher.") {
        items(listOf("Mod Maker", "Resource Pack Maker", "Modpack Maker", "Shader Maker")) { name ->
            ListCard(name, "Belum diaktifkan pada fondasi 0.3.0") {
                OutlinedButton(onClick = { }) { Text("BUKA") }
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    ContentList("Pengaturan", "Pengaturan launcher dan game.") {
        items(listOf("Kontrol", "RAM & Java Runtime", "Direktori game", "Akun", "Tampilan", "Tentang J Launcher")) { name ->
            ListCard(name, "Konfigurasi") { Text("›", color = Neon) }
        }
    }
}

@Composable
private fun ContentList(
    title: String,
    subtitle: String,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = {
            item {
                Text(title, style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Color.Gray)
            }
            content()
        }
    )
}

@Composable
private fun ListCard(title: String, subtitle: String, action: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Color.Gray)
            }
            action()
        }
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Neon, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color.Gray)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}
