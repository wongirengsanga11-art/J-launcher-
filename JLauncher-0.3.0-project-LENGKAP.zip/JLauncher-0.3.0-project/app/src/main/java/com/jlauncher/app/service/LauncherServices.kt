package com.jlauncher.app.service

/**
 * Integration boundary for real Minecraft services.
 *
 * Future implementation points:
 * - Mojang version manifest/downloads
 * - Microsoft authentication
 * - Ely.by authentication
 * - Secure offline/local profiles
 * - Fabric/Forge/NeoForge/OptiFine installers
 * - Mod/resource-pack/shader downloads
 * - Java runtime selection and Minecraft process launch
 */
interface AccountService {
    suspend fun signIn()
    suspend fun signOut()
}

interface MinecraftDownloadService {
    suspend fun installVersion(versionId: String)
}

interface MinecraftLaunchService {
    suspend fun launch(versionId: String)
}
