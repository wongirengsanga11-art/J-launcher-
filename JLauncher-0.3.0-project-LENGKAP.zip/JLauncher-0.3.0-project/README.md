# J Launcher 0.3.0

J Launcher adalah fondasi launcher Minecraft Java untuk Android.

## Isi project
- UI launcher neon/dark dengan dashboard
- Navigasi: Beranda, Versi, Mod & Modpack, Resource Pack, Shader, Maker, Pengaturan
- Struktur repository yang siap dikembangkan di Android Studio
- Model data untuk versi Minecraft, loader, mod, resource pack, shader
- Service/repository layer sebagai tempat integrasi downloader dan runtime
- Tombol Play, Install, Download, dan pengelolaan konten
- Manifest internet permission

## Build
Buka folder ini di Android Studio versi terbaru yang mendukung AGP 8.7.x.
Biarkan Android Studio mengunduh Gradle/dependency yang diperlukan, lalu:
**Build > Make Project** atau **Build > Build APK(s)**.

APK debug biasanya berada di:
`app/build/outputs/apk/debug/app-debug.apk`

## Catatan penting
Project ini adalah **source project fondasi aplikasi**. Minecraft Java runtime, autentikasi Microsoft/Ely.by, downloader manifest Mojang, Fabric/Forge/NeoForge/OptiFine, dan proses launch game belum terhubung ke backend/runtime nyata di versi ini. Jangan menganggap tombol UI sebagai implementasi fitur tersebut.

## Identitas
Application ID: `com.jlauncher.app`
Version: `0.3.0`
Version code: `30`
