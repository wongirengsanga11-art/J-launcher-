package com.jlauncher.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080B12)
private val Panel = Color(0xFF111722)
private val Cyan = Color(0xFF27C9FF)
private val TextMain = Color(0xFFF4F7FB)
private val TextMuted = Color(0xFF8D9AAF)

data class Feature(val title: String, val subtitle: String, val icon: String)

data class MinecraftVersion(val version: String, val loader: String, val status: String)

private val versions = listOf(
    MinecraftVersion("1.21.8", "Vanilla", "Siap dipilih"),
    MinecraftVersion("1.21.1", "Fabric", "Siap dipilih"),
    MinecraftVersion("1.20.1", "Fabric", "Terpasang"),
    MinecraftVersion("1.20.1", "Forge", "Tersedia"),
    MinecraftVersion("1.20.1", "NeoForge", "Tersedia"),
    MinecraftVersion("1.16.5", "OptiFine", "Tersedia")
)

private val features = listOf(
    Feature("MAIN", "Mulai bermain Minecraft", "▶"),
    Feature("VERSI MINECRAFT", "Kelola & install versi", "⬇"),
    Feature("MOD & MODPACK", "Download dan kelola", "◆"),
    Feature("RESOURCE PACK", "Kelola resource pack", "▣"),
    Feature("SHADER", "Pasang dan kelola shader", "✦"),
    Feature("BUAT MOD", "Buat mod sendiri", "⚒"),
    Feature("BUAT RESOURCE PACK", "Buat resource pack", "▤"),
    Feature("BUAT MODPACK", "Kemas mod jadi modpack", "▰"),
    Feature("SHADER MAKER", "Buat shader sendiri", "◇"),
    Feature("PENGATURAN", "Launcher dan lainnya", "⚙")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JLauncherApp() }
    }
}

@Composable
fun JLauncherApp() {
    var selected by remember { mutableStateOf("MAIN") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = Cyan
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Header()
                Spacer(Modifier.height(16.dp))

                Text(
                    selected,
                    color = TextMain,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Fondasi launcher Minecraft Java Android • J Launcher 0.3.0",
                    color = TextMuted,
                    fontSize = 14.sp
                )

                Spacer(Modifier.height(18.dp))

                when (selected) {
                    "VERSI MINECRAFT" -> VersionScreen()
                    "PENGATURAN" -> SettingsScreen()
                    else -> {
                        PlayCard()
                        Spacer(Modifier.height(16.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 155.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(features) { feature ->
                                FeatureCard(feature) { selected = feature.title }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    "J Launcher 0.3.0 • Minecraft Java Edition on Android",
                    color = TextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}

@Composable
private fun Header() {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(48.dp).background(Cyan, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("J", color = Color.Black, fontSize = 28.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("J Launcher", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("Play Minecraft Java, Your Way", color = TextMuted, fontSize = 12.sp)
        }
        Text("⚙", color = TextMain, fontSize = 24.sp)
    }
}

@Composable
private fun PlayCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF102333)),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Minecraft Java", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Versi terakhir dipilih", color = TextMuted, fontSize = 12.sp)
                Text("1.20.1 • Fabric", color = Cyan, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
            Button(
                onClick = { },
                colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("MAIN", color = Color.Black, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun FeatureCard(feature: Feature, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().height(126.dp)
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(feature.icon, color = Cyan, fontSize = 25.sp)
            Column {
                Text(
                    feature.title,
                    color = TextMain,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    feature.subtitle,
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }
    }
}


@Composable
private fun VersionScreen() {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
        items(versions) { v ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(v.version, color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(v.loader, color = Cyan, fontSize = 13.sp)
                        Text(v.status, color = TextMuted, fontSize = 11.sp)
                    }
                    OutlinedButton(onClick = { }) { Text("PILIH") }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SettingRow("Akun", "Microsoft / Ely.by / Offline")
        SettingRow("RAM", "Otomatis")
        SettingRow("Kontrol", "Kustomisasi kontrol Android")
        SettingRow("Tema", "Neon Dark")
        SettingRow("Direktori game", "Belum dipilih")
    }
}

@Composable
private fun SettingRow(title: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(title, color = TextMain, fontWeight = FontWeight.Bold)
            Text(value, color = TextMuted, fontSize = 12.sp)
        }
    }
}
