# J Launcher 0.3.0

Fondasi Android J Launcher untuk Minecraft Java Edition.

## Yang ditambahkan di 0.3.0
- Dashboard/Game Bar dengan navigasi fitur.
- Daftar versi Minecraft contoh dari versi lama hingga terbaru.
- Pilihan loader Vanilla, Fabric, Forge, NeoForge, dan OptiFine sebagai fondasi UI.
- Halaman pengaturan akun, RAM, kontrol, tema, dan direktori game.
- Struktur UI siap dikembangkan menuju downloader, autentikasi, runtime Java, dan mod manager.

## Catatan
Ini masih fondasi aplikasi. Engine Minecraft Java, autentikasi online, downloader aset/game, runtime Java, dan integrasi loader belum disertakan.
